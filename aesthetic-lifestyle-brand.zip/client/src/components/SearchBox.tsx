import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

export default function SearchBox() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  // Fetch all products for search
  const { data: allProducts = [] } = trpc.commerce.products.list.useQuery();

  // Filter products based on search query
  const searchResults = query.trim()
    ? allProducts.filter(
        (p) =>
          p.title.toLowerCase().includes(query.toLowerCase()) ||
          p.description?.toLowerCase().includes(query.toLowerCase()) ||
          p.productType?.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
    }
  }, [isOpen]);

  // Close on escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsOpen(false);
      }
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, []);

  return (
    <div className="relative">
      {/* Search Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 hover:bg-secondary rounded-md transition-colors"
      >
        <Search className="w-5 h-5" />
      </motion.button>

      {/* Search Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/30 z-40"
            />

            {/* Search Panel */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ type: "spring", damping: 20, stiffness: 300 }}
              className="absolute top-full right-0 mt-2 w-96 max-w-[calc(100vw-2rem)] bg-background rounded-lg shadow-lg z-50 border border-border"
            >
              {/* Search Input */}
              <div className="p-4 border-b border-border flex items-center gap-2">
                <Search className="w-5 h-5 text-foreground/60" />
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Search products..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="flex-1 bg-transparent outline-none text-sm"
                />
                {query && (
                  <button
                    onClick={() => setQuery("")}
                    className="p-1 hover:bg-secondary rounded transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Results */}
              <div className="max-h-96 overflow-y-auto">
                {query.trim() === "" ? (
                  <div className="p-8 text-center text-foreground/60">
                    <p className="text-sm">Start typing to search</p>
                  </div>
                ) : searchResults.length === 0 ? (
                  <div className="p-8 text-center text-foreground/60">
                    <p className="text-sm">No products found</p>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {searchResults.slice(0, 8).map((product) => (
                      <Link key={product.id} href={`/product/${product.handle}`}>
                        <a
                          onClick={() => setIsOpen(false)}
                          className="flex gap-3 p-4 hover:bg-secondary/50 transition-colors"
                        >
                          {product.images[0] && (
                            <img
                              src={product.images[0].url}
                              alt={product.title}
                              className="w-12 h-12 rounded object-cover"
                            />
                          )}
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-sm line-clamp-1">
                              {product.title}
                            </h4>
                            <p className="text-xs text-foreground/60">
                              {product.productType}
                            </p>
                            <p className="text-sm font-semibold mt-1">
                              {product.priceRange.min.currencyCode}{" "}
                              {product.priceRange.min.amount}
                            </p>
                          </div>
                        </a>
                      </Link>
                    ))}
                  </div>
                )}

                {/* View All Results */}
                {searchResults.length > 8 && (
                  <div className="p-4 text-center border-t border-border">
                    <p className="text-xs text-foreground/60">
                      Showing 8 of {searchResults.length} results
                    </p>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
