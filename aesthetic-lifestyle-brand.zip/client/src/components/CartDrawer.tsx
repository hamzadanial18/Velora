import { useCart } from "@/contexts/CartContext";
import { motion, AnimatePresence } from "framer-motion";
import { X, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CartDrawer() {
  const {
    cart,
    isOpen,
    closeCart,
    removeItem,
    updateQuantity,
    proceedToCheckout,
    loading,
  } = useCart();

  if (!cart) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
            className="fixed inset-0 bg-black/30 z-40"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-background z-50 flex flex-col shadow-lg"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 md:p-6 border-b border-border">
              <h2 className="font-serif text-lg font-light tracking-wide">
                Shopping Cart
              </h2>
              <button
                onClick={closeCart}
                className="p-2 hover:bg-secondary rounded-md transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6">
              {cart.items.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-foreground/60 text-center">
                    Your cart is empty
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.items.map((item) => (
                    <motion.div
                      key={item.lineId}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="flex gap-4 pb-4 border-b border-border"
                    >
                      {/* Image */}
                      {item.image && (
                        <div className="w-20 h-20 rounded-lg overflow-hidden bg-secondary flex-shrink-0">
                          <img
                            src={item.image.url}
                            alt={item.productTitle}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-sans text-sm font-medium mb-1 line-clamp-1">
                          {item.productTitle}
                        </h3>
                        {item.variantTitle !== "Default Title" && (
                          <p className="text-xs text-foreground/60 mb-2">
                            {item.variantTitle}
                          </p>
                        )}
                        <p className="text-sm font-semibold mb-3">
                          {item.unitPrice.currencyCode} {item.unitPrice.amount}
                        </p>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              updateQuantity(
                                item.lineId,
                                Math.max(0, item.quantity - 1)
                              )
                            }
                            className="px-2 py-1 text-xs border border-border rounded hover:bg-secondary transition-colors"
                          >
                            −
                          </button>
                          <span className="text-xs font-medium w-6 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              updateQuantity(item.lineId, item.quantity + 1)
                            }
                            className="px-2 py-1 text-xs border border-border rounded hover:bg-secondary transition-colors"
                          >
                            +
                          </button>
                          <button
                            onClick={() => removeItem(item.lineId)}
                            className="ml-auto p-1 text-foreground/60 hover:text-destructive transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {cart.items.length > 0 && (
              <div className="border-t border-border p-4 md:p-6 space-y-4">
                {/* Totals */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground/60">Subtotal</span>
                    <span>
                      {cart.subtotal.currencyCode} {cart.subtotal.amount}
                    </span>
                  </div>
                  <div className="flex justify-between text-base font-semibold pt-2 border-t border-border">
                    <span>Total</span>
                    <span>
                      {cart.total.currencyCode} {cart.total.amount}
                    </span>
                  </div>
                </div>

                {/* Checkout Button */}
                <Button
                  onClick={proceedToCheckout}
                  disabled={loading || cart.items.length === 0}
                  className="w-full"
                  size="lg"
                >
                  {loading ? "Processing..." : "Proceed to Checkout"}
                </Button>

                <Button
                  onClick={closeCart}
                  variant="outline"
                  className="w-full"
                  size="lg"
                >
                  Continue Shopping
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
