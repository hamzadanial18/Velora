import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="container py-12 md:py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <h3 className="font-serif text-lg font-light tracking-widest mb-4">
              VELORA
            </h3>
            <p className="text-sm text-foreground/60 leading-relaxed">
              Curated luxury lifestyle products for the discerning individual.
            </p>
          </div>

          {/* Shop */}
          <div>
            <h4 className="font-sans font-semibold text-sm mb-4 text-foreground/80">
              SHOP
            </h4>
            <ul className="space-y-2 text-sm text-foreground/60">
              <li>
                <Link href="/shop/clothing">
                  <a className="hover:text-foreground transition-colors">
                    Clothing
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/shop/watches">
                  <a className="hover:text-foreground transition-colors">
                    Watches
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/shop/necklaces">
                  <a className="hover:text-foreground transition-colors">
                    Necklaces
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/shop/rings">
                  <a className="hover:text-foreground transition-colors">
                    Rings
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/shop/home-decor">
                  <a className="hover:text-foreground transition-colors">
                    Home Decor
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-sans font-semibold text-sm mb-4 text-foreground/80">
              SUPPORT
            </h4>
            <ul className="space-y-2 text-sm text-foreground/60">
              <li>
                <a href="mailto:nmvelora.co@gmail.com" className="hover:text-foreground transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Shipping Info
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Returns
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-sans font-semibold text-sm mb-4 text-foreground/80">
              LEGAL
            </h4>
            <ul className="space-y-2 text-sm text-foreground/60">
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-foreground/60">
          <p>&copy; {currentYear} VELORA. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="https://www.tiktok.com/@ve.lora43?_r=1&_t=ZS-97VOZQCeTyO" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">
              TikTok
            </a>
            <a href="https://youtube.com/@velora-h2c?si=xOwCbQ-w5rFUmmgS" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">
              YouTube
            </a>
            <a href="mailto:nmvelora.co@gmail.com" className="hover:text-foreground transition-colors">
              Email
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
