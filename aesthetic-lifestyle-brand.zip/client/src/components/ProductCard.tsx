import { Product } from "@shared/commerce/types";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { Heart } from "lucide-react";
import { useState } from "react";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const firstImage = product.images[0];
  const firstVariant = product.variants[0];
  const price = firstVariant?.price;

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!firstVariant) return;

    setIsLoading(true);
    try {
      await addItem(firstVariant.id, 1);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Link href={`/product/${product.handle}`}>
      <a className="group block h-full">
        <motion.div
          whileHover={{ y: -8, scale: 1.02 }}
          transition={{ duration: 0.3, type: "spring", stiffness: 300, damping: 20 }}
          className="h-full flex flex-col"
          style={{ perspective: "1000px" }}
        >
          {/* Image Container with 3D Effect */}
          <motion.div
            whileHover={{ rotateX: 5, rotateY: -5 }}
            transition={{ duration: 0.4 }}
            className="relative bg-secondary rounded-lg overflow-hidden mb-4 aspect-square shadow-lg group-hover:shadow-2xl transition-shadow"
            style={{ perspective: "1000px" }}
          >
            {firstImage && (
              <motion.img
                src={firstImage.url}
                alt={product.title}
                className="w-full h-full object-cover"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              />
            )}

            {/* Wishlist Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.preventDefault();
                setIsWishlisted(!isWishlisted);
              }}
              className="absolute top-3 right-3 p-2 bg-white/90 rounded-full hover:bg-white transition-colors"
            >
              <Heart
                className={`w-4 h-4 ${
                  isWishlisted ? "fill-red-500 text-red-500" : "text-foreground"
                }`}
              />
            </motion.button>

            {/* Quick Add Button with 3D Animation */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileHover={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, type: "spring", stiffness: 400 }}
              className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/20 flex items-end justify-center pb-6 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-4/5"
              >
                <Button
                  size="sm"
                  onClick={handleAddToCart}
                  disabled={isLoading || !firstVariant?.availableForSale}
                  className="w-full bg-white text-foreground hover:bg-white/90 font-medium"
                >
                  {isLoading ? "Adding..." : "Add to Cart"}
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Product Info with Stagger Animation */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            viewport={{ once: true }}
            className="flex-1"
          >
            <h3 className="font-serif text-sm md:text-base font-light tracking-wide mb-2 line-clamp-2">
              {product.title}
            </h3>

            <p className="text-xs md:text-sm text-foreground/60 mb-3 line-clamp-2">
              {product.productType}
            </p>

            {/* Price */}
            <div className="flex items-baseline gap-2">
              <span className="font-sans text-sm md:text-base font-semibold">
                {price?.currencyCode} {price?.amount}
              </span>
              {product.priceRange.min.amount !==
                product.priceRange.max.amount && (
                <span className="text-xs text-foreground/50">
                  - {product.priceRange.max.currencyCode}{" "}
                  {product.priceRange.max.amount}
                </span>
              )}
            </div>

            {/* Availability */}
            {!firstVariant?.availableForSale && (
              <p className="text-xs text-destructive mt-2">Out of Stock</p>
            )}
          </motion.div>
        </motion.div>
      </a>
    </Link>
  );
}
