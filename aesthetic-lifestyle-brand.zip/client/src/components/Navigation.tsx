import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Menu, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import SearchBox from "./SearchBox";

const categories = [
  { name: "Clothing", href: "/shop/clothing" },
  { name: "Watches", href: "/shop/watches" },
  { name: "Necklaces", href: "/shop/necklaces" },
  { name: "Rings", href: "/shop/rings" },
  { name: "Home Decor", href: "/shop/home-decor" },
];

export default function Navigation() {
  const { itemCount, openCart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container flex items-center justify-between h-16 md:h-20">
        {/* Logo */}
        <Link href="/">
          <span className="text-xl md:text-2xl font-serif font-light tracking-widest hover:opacity-70 transition-opacity cursor-pointer">
            VELORA
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {categories.map((category) => (
            <Link key={category.href} href={category.href}>
              <span className="text-sm font-sans font-medium text-foreground/80 hover:text-foreground transition-colors duration-300 cursor-pointer">
                {category.name}
              </span>
            </Link>
          ))}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {/* Search */}
          <SearchBox />

          {/* Cart Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={openCart}
            className="relative p-2 hover:bg-secondary rounded-md transition-colors"
          >
            <ShoppingBag className="w-5 h-5" />
            {itemCount > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium"
              >
                {itemCount}
              </motion.span>
            )}
          </motion.button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="md:hidden border-t border-border bg-background"
        >
          <div className="container py-4 flex flex-col gap-3">
            {categories.map((category) => (
              <Link key={category.href} href={category.href}>
                <span
                  className="text-sm font-medium text-foreground/80 hover:text-foreground transition-colors py-2 cursor-pointer block"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {category.name}
                </span>
              </Link>
            ))}
          </div>
        </motion.div>
      )}
    </nav>
  );
}
