import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { ArrowRight } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, ease: [0.23, 1, 0.32, 1] },
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.3,
    },
  },
};

const floatingAnimation = {
  animate: {
    y: [0, -30, 0],
    rotateZ: [0, 5, -5, 0],
  },
  transition: {
    duration: 8,
    repeat: Infinity,
    ease: "easeInOut",
  },
};

const scaleOnHover = {
  whileHover: { scale: 1.05 },
  whileTap: { scale: 0.95 },
};

export default function Home() {
  const containerRef = useRef(null);
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 150]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0.3]);

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <Navigation />

      {/* Hero Section with 3D Depth */}
      <section className="relative h-screen md:h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-b from-secondary via-background to-background perspective">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          {/* Floating Orbs with 3D effect */}
          <motion.div
            animate={{
              y: [0, 40, 0],
              x: [0, 20, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-br from-primary/40 to-primary/10 rounded-full blur-3xl"
            style={{
              filter: "drop-shadow(0 0 60px rgba(139, 69, 19, 0.3))",
            }}
          />
          <motion.div
            animate={{
              y: [0, -40, 0],
              x: [0, -20, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1,
            }}
            className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-br from-accent/30 to-accent/5 rounded-full blur-3xl"
            style={{
              filter: "drop-shadow(0 0 50px rgba(139, 69, 19, 0.2))",
            }}
          />
        </div>

        {/* Parallax Text Container */}
        <motion.div
          ref={containerRef}
          style={{ y, opacity }}
          className="container relative z-10 text-center"
        >
          <motion.div
            initial="initial"
            animate="animate"
            variants={staggerContainer}
            className="space-y-8"
          >
            {/* 3D Rotating Title */}
            <motion.div
              variants={fadeInUp}
              className="perspective"
            >
              <motion.h1
                animate={{
                  rotateX: [0, 5, 0],
                  rotateY: [0, -5, 0],
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="text-6xl md:text-8xl lg:text-9xl font-serif font-light tracking-tight"
                style={{
                  textShadow: "0 10px 40px rgba(139, 69, 19, 0.2)",
                  perspective: "1000px",
                }}
              >
                VELORA
              </motion.h1>
            </motion.div>

            {/* Animated Subtitle */}
            <motion.p
              variants={fadeInUp}
              className="text-lg md:text-2xl text-foreground/70 max-w-3xl mx-auto font-light leading-relaxed"
              style={{
                textShadow: "0 4px 20px rgba(139, 69, 19, 0.1)",
              }}
            >
              Curated luxury lifestyle products for those who appreciate refined
              elegance, timeless design, and authentic beauty.
            </motion.p>

            {/* CTA Buttons with 3D Effect */}
            <motion.div
              variants={fadeInUp}
              className="flex flex-col sm:flex-row gap-4 justify-center pt-8"
            >
              <motion.div
                whileHover={{ scale: 1.08, y: -5 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <Link href="/shop/clothing" asChild>
                  <Button
                    size="lg"
                    className="group bg-primary hover:bg-primary/90 text-white px-8 py-6 text-lg font-medium shadow-lg hover:shadow-2xl transition-all duration-300"
                  >
                    Explore Collection
                    <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-2 transition-transform" />
                  </Button>
                </Link>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.08, y: -5 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <Button
                  size="lg"
                  variant="outline"
                  className="px-8 py-6 text-lg font-medium border-2 hover:bg-foreground/5 transition-all duration-300"
                >
                  Learn Our Story
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20"
        >
          <div className="w-6 h-10 border-2 border-foreground/40 rounded-full flex justify-center">
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1 h-2 bg-foreground/40 rounded-full mt-2"
            />
          </div>
        </motion.div>
      </section>

      {/* Brand Story Section with 3D Cards */}
      <section className="py-20 md:py-32 bg-background relative overflow-hidden">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="grid md:grid-cols-2 gap-12 items-center"
          >
            {/* Image with 3D Tilt Effect */}
            <motion.div
              whileHover={{
                rotateX: 5,
                rotateY: -5,
                scale: 1.02,
              }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="relative h-96 md:h-[500px] rounded-lg overflow-hidden shadow-2xl"
              style={{
                perspective: "1000px",
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20" />
              <img
                src="https://images.unsplash.com/photo-1556821552-5ff63b1b6d6d?w=600&h=600&fit=crop"
                alt="Luxury lifestyle"
                className="w-full h-full object-cover"
              />
            </motion.div>

            {/* Text Content with Stagger */}
            <motion.div
              className="space-y-6"
              initial="initial"
              whileInView="animate"
              variants={staggerContainer}
              viewport={{ once: true, margin: "-100px" }}
            >
              <motion.h2
                variants={fadeInUp}
                className="text-4xl md:text-5xl font-serif font-light tracking-wide"
              >
                Our Philosophy
              </motion.h2>

              <motion.p
                variants={fadeInUp}
                className="text-foreground/70 leading-relaxed text-lg"
              >
                At VELORA, we believe that luxury is not about excess—it's
                about intention. Every piece in our collection is carefully
                selected for its quality, craftsmanship, and timeless appeal.
              </motion.p>

              <motion.p
                variants={fadeInUp}
                className="text-foreground/70 leading-relaxed text-lg"
              >
                We partner with artisans and designers who share our commitment
                to creating products that endure, both in durability and in
                style. Our mission is to help you build a life of refined
                elegance.
              </motion.p>

              <motion.div
                variants={fadeInUp}
                whileHover={{ x: 10 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Button size="lg" variant="outline">
                  Read Full Story
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Lookbook Section with 3D Grid */}
      <section className="py-20 md:py-32 bg-secondary/30 relative overflow-hidden">
        <div className="container">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-serif font-light tracking-wide mb-4"
            >
              Lookbook
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-foreground/60 text-lg"
            >
              Discover how our products come together in curated lifestyle moments.
            </motion.p>
          </motion.div>

          {/* 3D Lookbook Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((item, index) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                whileHover={{
                  rotateY: -10,
                  scale: 1.05,
                  y: -20,
                }}
                className="relative h-80 rounded-lg overflow-hidden cursor-pointer group shadow-lg hover:shadow-2xl transition-shadow"
                style={{
                  perspective: "1000px",
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-gray-400 to-gray-600" />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all duration-300" />

                <motion.div
                  className="absolute inset-0 flex flex-col justify-end p-6 text-white"
                  initial={{ y: 20, opacity: 0 }}
                  whileHover={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <h3 className="text-2xl font-serif font-light mb-2">
                    Collection {item}
                  </h3>
                  <motion.button
                    whileHover={{ x: 5 }}
                    className="text-sm font-medium flex items-center gap-2 w-fit"
                  >
                    Explore
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Journal Section with Staggered Cards */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-serif font-light tracking-wide mb-4"
            >
              Journal
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-foreground/60 text-lg"
            >
              Stories, insights, and inspiration from the world of aesthetic living.
            </motion.p>
          </motion.div>

          {/* Blog Cards with 3D Effect */}
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "The Art of Minimalism", date: "June 20, 2026" },
              { title: "Sustainable Luxury", date: "June 15, 2026" },
              { title: "Timeless Design Principles", date: "June 10, 2026" },
            ].map((post, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                whileHover={{
                  rotateX: 5,
                  rotateY: 5,
                  scale: 1.03,
                  y: -10,
                }}
                className="group cursor-pointer"
                style={{
                  perspective: "1000px",
                }}
              >
                <div className="relative h-64 rounded-lg overflow-hidden mb-4 shadow-lg group-hover:shadow-2xl transition-shadow">
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-300 to-gray-400" />
                  <motion.div
                    className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300"
                  />
                </div>

                <motion.h3
                  className="text-xl font-serif font-light mb-2 group-hover:text-primary transition-colors"
                >
                  {post.title}
                </motion.h3>

                <p className="text-sm text-foreground/60 mb-4">{post.date}</p>

                <motion.button
                  whileHover={{ x: 5 }}
                  className="text-sm font-medium text-primary flex items-center gap-2"
                >
                  Read More
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
