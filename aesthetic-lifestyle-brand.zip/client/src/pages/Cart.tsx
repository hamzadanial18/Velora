import { motion } from "framer-motion";
import { useCart } from "@/contexts/CartContext";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Trash2, Plus, Minus, ArrowRight } from "lucide-react";

export default function Cart() {
  const { cart, removeItem, updateQuantity, proceedToCheckout, loading } =
    useCart();

  if (!cart || cart.items.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-serif font-light mb-4">
              Your Cart is Empty
            </h1>
            <p className="text-foreground/60 mb-8">
              Explore our collection and find something you love.
            </p>
            <Link href="/shop/clothing">
              <Button size="lg" className="group" asChild>
                <a>
                  Continue Shopping
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </a>
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <div className="flex-1 container py-12 md:py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-5xl font-serif font-light tracking-wide mb-12">
            Shopping Cart
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {cart.items.map((item, i) => (
                  <motion.div
                    key={item.lineId}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: i * 0.05 }}
                    className="flex gap-6 p-6 bg-secondary/30 rounded-lg hover:bg-secondary/50 transition-colors"
                  >
                    {/* Image */}
                    {item.image && (
                      <div className="w-24 h-24 rounded-lg overflow-hidden bg-secondary flex-shrink-0">
                        <img
                          src={item.image.url}
                          alt={item.productTitle}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {/* Product Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-serif text-lg font-light mb-1">
                        {item.productTitle}
                      </h3>
                      {item.variantTitle !== "Default Title" && (
                        <p className="text-sm text-foreground/60 mb-3">
                          {item.variantTitle}
                        </p>
                      )}
                      <p className="text-lg font-semibold mb-4">
                        {item.unitPrice.currencyCode} {item.unitPrice.amount}
                      </p>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() =>
                            updateQuantity(
                              item.lineId,
                              Math.max(0, item.quantity - 1)
                            )
                          }
                          className="p-2 border border-border rounded hover:bg-background transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-sm font-medium w-8 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(item.lineId, item.quantity + 1)
                          }
                          className="p-2 border border-border rounded hover:bg-background transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Total & Remove */}
                    <div className="flex flex-col items-end justify-between">
                      <div className="text-right">
                        <p className="text-sm text-foreground/60 mb-2">
                          Total
                        </p>
                        <p className="text-lg font-semibold">
                          {item.unitPrice.currencyCode}{" "}
                          {(
                            parseFloat(item.unitPrice.amount) * item.quantity
                          ).toFixed(2)}
                        </p>
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => removeItem(item.lineId)}
                        className="p-2 text-foreground/60 hover:text-destructive transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Continue Shopping */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.3 }}
                className="mt-8"
              >
                <Link href="/shop/clothing">
                  <span className="text-primary hover:underline text-sm font-medium flex items-center gap-2 cursor-pointer">
                    ← Continue Shopping
                  </span>
                </Link>
              </motion.div>
            </div>

            {/* Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-1"
            >
              <div className="sticky top-24 bg-secondary/30 rounded-lg p-6 space-y-6">
                <h2 className="font-serif text-xl font-light">
                  Order Summary
                </h2>

                {/* Breakdown */}
                <div className="space-y-3 pb-6 border-b border-border">
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground/60">Subtotal</span>
                    <span>
                      {cart.subtotal.currencyCode} {cart.subtotal.amount}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground/60">Shipping</span>
                    <span className="text-green-600 font-medium">Free</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground/60">Tax</span>
                    <span>Calculated at checkout</span>
                  </div>
                </div>

                {/* Total */}
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span>
                    {cart.total.currencyCode} {cart.total.amount}
                  </span>
                </div>

                {/* Checkout Button */}
                <Button
                  onClick={proceedToCheckout}
                  disabled={loading}
                  className="w-full"
                  size="lg"
                >
                  {loading ? "Processing..." : "Proceed to Checkout"}
                </Button>

                {/* Trust Badges */}
                <div className="text-xs text-foreground/60 space-y-2 pt-4 border-t border-border">
                  <p className="flex items-start gap-2">
                    <span>✓</span>
                    <span>Free shipping on orders over $100</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span>✓</span>
                    <span>30-day returns on all items</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span>✓</span>
                    <span>Secure checkout with SSL encryption</span>
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      <Footer />
      <CartDrawer />
    </div>
  );
}
