import { motion } from "framer-motion";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import ProductCard from "@/components/ProductCard";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

const categories = [
  { id: "clothing", name: "Clothing", handle: "clothing" },
  { id: "watches", name: "Watches", handle: "watches" },
  { id: "necklaces", name: "Necklaces", handle: "necklaces" },
  { id: "rings", name: "Rings", handle: "rings" },
  { id: "home-decor", name: "Home Decor", handle: "home-decor" },
];

export default function Shop() {
  const [, params] = useRoute("/shop/:category");
  const category = params?.category || "clothing";

  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [sortBy, setSortBy] = useState("newest");

  // Fetch products - for now, fetch all and filter client-side
  const { data: products = [], isLoading } = trpc.commerce.products.list.useQuery();

  // Filter products by category (using productType)
  const categoryObj = categories.find((c) => c.handle === category);
  const filteredProducts = products.filter((p) => {
    if (!categoryObj || !p.productType) return true;
    return (
      p.productType.toLowerCase() === categoryObj.name.toLowerCase()
    );
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return (
          parseFloat(a.priceRange.min.amount) -
          parseFloat(b.priceRange.min.amount)
        );
      case "price-high":
        return (
          parseFloat(b.priceRange.min.amount) -
          parseFloat(a.priceRange.min.amount)
        );
      case "newest":
      default:
        return 0;
    }
  });

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Page Header */}
      <section className="py-12 md:py-16 bg-secondary/30 border-b border-border">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-serif font-light tracking-wide mb-4">
              {categoryObj?.name || "Shop"}
            </h1>
            <p className="text-foreground/60 text-lg">
              Discover our curated collection of {categoryObj?.name.toLowerCase()}.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="md:col-span-1"
          >
            <div className="sticky top-24 space-y-6">
              {/* Categories */}
              <div>
                <h3 className="font-serif text-lg font-light mb-4">
                  Categories
                </h3>
                <div className="space-y-2">
                  {categories.map((cat) => (
                    <a
                      key={cat.id}
                      href={`/shop/${cat.handle}`}
                      className={`block text-sm py-2 px-3 rounded transition-colors ${
                        category === cat.handle
                          ? "bg-primary text-primary-foreground font-medium"
                          : "text-foreground/70 hover:text-foreground hover:bg-secondary"
                      }`}
                    >
                      {cat.name}
                    </a>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div>
                <h3 className="font-serif text-lg font-light mb-4">Price</h3>
                <div className="space-y-3">
                  <input
                    type="range"
                    min="0"
                    max="1000"
                    value={priceRange[1]}
                    onChange={(e) =>
                      setPriceRange([priceRange[0], parseInt(e.target.value)])
                    }
                    className="w-full"
                  />
                  <div className="flex gap-2 text-sm">
                    <span>${priceRange[0]}</span>
                    <span>-</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>
              </div>

              {/* Sort */}
              <div>
                <h3 className="font-serif text-lg font-light mb-4">Sort</h3>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md bg-background text-sm"
                >
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
            </div>
          </motion.div>

          {/* Products Grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="md:col-span-3"
          >
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="aspect-square rounded-lg" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : sortedProducts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-foreground/60 text-lg">
                  No products found in this category.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedProducts.map((product, i) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: i * 0.05 }}
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>

      <Footer />
      <CartDrawer />
    </div>
  );
}
