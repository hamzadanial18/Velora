import { motion } from "framer-motion";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { useCart } from "@/contexts/CartContext";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Heart, Share2, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:handle");
  const handle = params?.handle || "";

  const { data: product, isLoading } = trpc.commerce.products.byHandle.useQuery(
    { handle },
    { enabled: Boolean(handle) }
  );

  const { addItem, loading: cartLoading } = useCart();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <Skeleton className="aspect-square rounded-lg" />
            <div className="space-y-6">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-32" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container py-12 text-center">
          <h1 className="text-2xl font-serif mb-4">Product Not Found</h1>
          <Link href="/">
            <span className="text-primary hover:underline cursor-pointer">Back to Home</span>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const selectedImage = product.images[selectedImageIndex];
  const firstVariant = product.variants[0];

  const handleAddToCart = async () => {
    if (!firstVariant) return;
    await addItem(firstVariant.id, quantity);
    setQuantity(1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Image Gallery */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            {/* Main Image with 3D Effect */}
            <motion.div
              whileHover={{ rotateX: 5, rotateY: -5, scale: 1.02 }}
              transition={{ duration: 0.4 }}
              className="relative bg-secondary rounded-lg overflow-hidden aspect-square shadow-xl hover:shadow-2xl transition-shadow"
              style={{ perspective: "1000px" }}
            >
              {selectedImage && (
                <motion.img
                  key={selectedImageIndex}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  src={selectedImage.url}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              )}

              {/* Image Navigation */}
              {product.images.length > 1 && (
                <>
                  <button
                    onClick={() =>
                      setSelectedImageIndex(
                        (selectedImageIndex - 1 + product.images.length) %
                          product.images.length
                      )
                    }
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/80 rounded-full hover:bg-white transition-colors"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() =>
                      setSelectedImageIndex(
                        (selectedImageIndex + 1) % product.images.length
                      )
                    }
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/80 rounded-full hover:bg-white transition-colors"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}
            </motion.div>

            {/* Thumbnail Gallery with 3D Hover */}
            {product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-3">
                {product.images.map((image, i) => (
                  <motion.button
                    key={i}
                    onClick={() => setSelectedImageIndex(i)}
                    whileHover={{ scale: 1.1, rotateZ: 2, y: -4 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all shadow-md hover:shadow-lg ${
                      selectedImageIndex === i
                        ? "border-primary shadow-lg"
                        : "border-border hover:border-primary/50"
                    }`}
                    style={{ perspective: "1000px" }}
                  >
                    <motion.img
                      src={image.url}
                      alt={`${product.title} ${i + 1}`}
                      className="w-full h-full object-cover"
                      whileHover={{ scale: 1.1 }}
                    />
                  </motion.button>
                ))}
              </div>
            )}
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            {/* Title & Type */}
            <div>
              <p className="text-sm text-foreground/60 mb-2">
                {product.productType}
              </p>
              <h1 className="text-4xl md:text-5xl font-serif font-light tracking-wide mb-4">
                {product.title}
              </h1>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-semibold">
                {firstVariant?.price.currencyCode}{" "}
                {firstVariant?.price.amount}
              </span>
              {firstVariant?.compareAtPrice && (
                <span className="text-lg text-foreground/50 line-through">
                  {firstVariant.compareAtPrice.currencyCode}{" "}
                  {firstVariant.compareAtPrice.amount}
                </span>
              )}
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-amber-400 text-amber-400"
                  />
                ))}
              </div>
              <span className="text-sm text-foreground/60">(24 reviews)</span>
            </div>

            {/* Description */}
            <div className="prose prose-sm max-w-none">
              <p className="text-foreground/70 leading-relaxed text-lg">
                {product.description}
              </p>
            </div>

            {/* Availability */}
            <div className="flex items-center gap-3">
              <div
                className={`w-3 h-3 rounded-full ${
                  firstVariant?.availableForSale
                    ? "bg-green-500"
                    : "bg-red-500"
                }`}
              />
              <span className="text-sm font-medium">
                {firstVariant?.availableForSale
                  ? "In Stock"
                  : "Out of Stock"}
              </span>
            </div>

            {/* Quantity Selector */}
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">Quantity:</span>
              <div className="flex items-center border border-border rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-2 hover:bg-secondary transition-colors"
                >
                  −
                </button>
                <span className="px-6 py-2 font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4 py-2 hover:bg-secondary transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-4">
              <Button
                onClick={handleAddToCart}
                disabled={
                  cartLoading ||
                  !firstVariant?.availableForSale
                }
                size="lg"
                className="flex-1"
              >
                {cartLoading ? "Adding..." : "Add to Cart"}
              </Button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsWishlisted(!isWishlisted)}
                className="p-3 border border-border rounded-lg hover:bg-secondary transition-colors"
              >
                <Heart
                  className={`w-5 h-5 ${
                    isWishlisted
                      ? "fill-red-500 text-red-500"
                      : "text-foreground"
                  }`}
                />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-3 border border-border rounded-lg hover:bg-secondary transition-colors"
              >
                <Share2 className="w-5 h-5" />
              </motion.button>
            </div>

            {/* Product Details */}
            <div className="border-t border-border pt-6 space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Product Details</h3>
                <ul className="text-sm text-foreground/70 space-y-1">
                  <li>
                    <strong>Vendor:</strong> {product.vendor}
                  </li>
                  {product.tags && product.tags.length > 0 && (
                    <li>
                      <strong>Tags:</strong> {product.tags.join(", ")}
                    </li>
                  )}
                </ul>
              </div>
            </div>

            {/* Sizing Guide */}
            <div className="border-t border-border pt-6">
              <h3 className="font-semibold mb-4">Sizing Guide</h3>
              <div className="bg-secondary/30 rounded-lg p-4 text-sm text-foreground/70">
                <p className="mb-3">
                  Please refer to the size chart below for accurate measurements:
                </p>
                <ul className="space-y-2">
                  <li>• XS: Chest 32-34 in, Waist 24-26 in</li>
                  <li>• S: Chest 34-36 in, Waist 26-28 in</li>
                  <li>• M: Chest 36-38 in, Waist 28-30 in</li>
                  <li>• L: Chest 38-40 in, Waist 30-32 in</li>
                  <li>• XL: Chest 40-42 in, Waist 32-34 in</li>
                </ul>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Customer Reviews Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="border-t border-border pt-16 mb-16"
        >
          <h2 className="text-3xl font-serif font-light tracking-wide mb-8">
            Customer Reviews
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-secondary/30 rounded-lg p-6">
              <div className="flex items-center justify-between mb-3">
                <p className="font-semibold">Exceptional Quality</p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-amber-400 text-amber-400"
                    />
                  ))}
                </div>
              </div>
              <p className="text-sm text-foreground/70 mb-3">
                Absolutely beautiful piece. The craftsmanship is impeccable and
                the attention to detail is remarkable. Highly recommend!
              </p>
              <p className="text-xs text-foreground/50">— Sarah M.</p>
            </div>
            <div className="bg-secondary/30 rounded-lg p-6">
              <div className="flex items-center justify-between mb-3">
                <p className="font-semibold">Perfect Fit</p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-amber-400 text-amber-400"
                    />
                  ))}
                </div>
              </div>
              <p className="text-sm text-foreground/70 mb-3">
                Fits perfectly and feels luxurious. The material is premium
                quality and worth every penny.
              </p>
              <p className="text-xs text-foreground/50">— James K.</p>
            </div>
          </div>
        </motion.div>

        {/* Related Products Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="border-t border-border pt-16"
        >
          <h2 className="text-3xl font-serif font-light tracking-wide mb-8">
            You May Also Like
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center text-foreground/60">
              <p>More products coming soon</p>
            </div>
          </div>
        </motion.div>
      </div>

      <Footer />
      <CartDrawer />
    </div>
  );
}
