import { motion } from "framer-motion";
import { useState } from "react";
import { useCart } from "@/contexts/CartContext";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { Link } from "wouter";
import { ChevronRight, Check } from "lucide-react";

type CheckoutStep = "cart" | "shipping" | "payment" | "confirmation";

export default function Checkout() {
  const { cart, itemCount } = useCart();
  const { isAuthenticated } = useAuth();
  const [step, setStep] = useState<CheckoutStep>("cart");
  const [isGuest, setIsGuest] = useState(!isAuthenticated);

  // Form state
  const [formData, setFormData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    country: "",
  });

  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<"easypaisa" | "jazzcash" | "creditcard">("creditcard");
  const [transactionRef, setTransactionRef] = useState("");
  const [cardData, setCardData] = useState({
    cardName: "",
    cardNumber: "",
    expiry: "",
    cvc: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCardData((prev) => ({ ...prev, [name]: value }));
  };

  const handleNext = () => {
    if (step === "cart") setStep("shipping");
    else if (step === "shipping") setStep("payment");
    else if (step === "payment") {
      // Validate payment method
      if (paymentMethod === "easypaisa" || paymentMethod === "jazzcash") {
        if (!transactionRef.trim()) {
          alert("Please enter your transaction reference number");
          return;
        }
      } else if (paymentMethod === "creditcard") {
        if (!cardData.cardNumber.trim() || !cardData.cvc.trim()) {
          alert("Please enter valid card details");
          return;
        }
      }
      setStep("confirmation");
    }
  };

  const handleBack = () => {
    if (step === "shipping") setStep("cart");
    else if (step === "payment") setStep("shipping");
  };

  if (!cart) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container py-12 text-center">
          <h1 className="text-2xl font-serif mb-4">Cart is Empty</h1>
          <Link href="/">
            <span className="text-primary hover:underline cursor-pointer">Continue Shopping</span>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container py-12 md:py-16">
        {/* Progress Indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-between max-w-2xl">
            {(["cart", "shipping", "payment", "confirmation"] as const).map(
              (s, i) => (
                <div key={s} className="flex items-center">
                  <motion.div
                    animate={{
                      backgroundColor:
                        step === s || (i < ["cart", "shipping", "payment", "confirmation"].indexOf(step))
                          ? "var(--color-primary)"
                          : "var(--color-secondary)",
                    }}
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold"
                  >
                    {i < ["cart", "shipping", "payment", "confirmation"].indexOf(step) ? (
                      <Check className="w-5 h-5" />
                    ) : (
                      i + 1
                    )}
                  </motion.div>
                  {i < 3 && (
                    <div
                      className={`w-12 h-1 mx-2 ${
                        i < ["cart", "shipping", "payment", "confirmation"].indexOf(step)
                          ? "bg-primary"
                          : "bg-border"
                      }`}
                    />
                  )}
                </div>
              )
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Cart Review */}
            {step === "cart" && (
              <Card className="p-6 md:p-8">
                <h2 className="text-2xl font-serif font-light mb-6">Order Review</h2>
                <div className="space-y-4 mb-6">
                  {cart.items.map((item) => (
                    <motion.div
                      key={item.lineId}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex justify-between items-center pb-4 border-b border-border"
                    >
                      <div>
                        <p className="font-medium">{item.productTitle}</p>
                        <p className="text-sm text-foreground/60">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-medium">${item.lineTotal.amount}</p>
                    </motion.div>
                  ))}
                </div>

                {/* Guest vs Account */}
                {!isAuthenticated && (
                  <div className="mb-6 p-4 bg-secondary/50 rounded-lg">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        checked={isGuest}
                        onChange={() => setIsGuest(true)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm font-medium">
                        Continue as Guest
                      </span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer mt-3">
                      <input
                        type="radio"
                        checked={!isGuest}
                        onChange={() => setIsGuest(false)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm font-medium">
                        Sign In to Account
                      </span>
                    </label>
                  </div>
                )}
              </Card>
            )}

            {/* Shipping Information */}
            {step === "shipping" && (
              <Card className="p-6 md:p-8">
                <h2 className="text-2xl font-serif font-light mb-6">
                  Shipping Address
                </h2>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        placeholder="John"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        placeholder="Doe"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="123 Main St"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="New York"
                      />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        placeholder="NY"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="zip">ZIP Code</Label>
                      <Input
                        id="zip"
                        name="zip"
                        value={formData.zip}
                        onChange={handleInputChange}
                        placeholder="10001"
                      />
                    </div>
                    <div>
                      <Label htmlFor="country">Country</Label>
                      <Input
                        id="country"
                        name="country"
                        value={formData.country}
                        onChange={handleInputChange}
                        placeholder="United States"
                      />
                    </div>
                  </div>
                </div>
              </Card>
            )}

            {/* Payment Information */}
            {step === "payment" && (
              <Card className="p-6 md:p-8">
                <h2 className="text-2xl font-serif font-light mb-6">
                  Payment Method
                </h2>
                <div className="space-y-4">
                  {/* Easypaisa */}
                  <div
                    onClick={() => setPaymentMethod("easypaisa")}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                      paymentMethod === "easypaisa"
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="easypaisa"
                        checked={paymentMethod === "easypaisa"}
                        onChange={(e) => setPaymentMethod(e.target.value as "easypaisa")}
                        className="w-4 h-4"
                      />
                      <span className="font-medium">Easypaisa</span>
                      <span className="text-xs text-foreground/60 ml-auto">03119769550 - Aqsa Zareen</span>
                    </label>
                  </div>

                  {/* JazzCash */}
                  <div
                    onClick={() => setPaymentMethod("jazzcash")}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                      paymentMethod === "jazzcash"
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="jazzcash"
                        checked={paymentMethod === "jazzcash"}
                        onChange={(e) => setPaymentMethod(e.target.value as "jazzcash")}
                        className="w-4 h-4"
                      />
                      <span className="font-medium">JazzCash</span>
                    </label>
                  </div>

                  {/* Credit Card */}
                  <div
                    onClick={() => setPaymentMethod("creditcard")}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                      paymentMethod === "creditcard"
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="creditcard"
                        checked={paymentMethod === "creditcard"}
                        onChange={(e) => setPaymentMethod(e.target.value as "creditcard")}
                        className="w-4 h-4"
                      />
                      <span className="font-medium">Credit Card</span>
                    </label>
                  </div>

                  {/* Payment Details */}
                  <div className="space-y-4 mt-6 pt-6 border-t border-border">
                    {(paymentMethod === "easypaisa" || paymentMethod === "jazzcash") && (
                      <div>
                        <Label htmlFor="transactionRef">Transaction Reference Number</Label>
                        <Input
                          id="transactionRef"
                          placeholder="Enter your transaction reference"
                          value={transactionRef}
                          onChange={(e) => setTransactionRef(e.target.value)}
                        />
                        <p className="text-xs text-foreground/60 mt-2">
                          {paymentMethod === "easypaisa"
                            ? "Send payment to 03119769550 (Aqsa Zareen) and enter the transaction reference above."
                            : "Send payment via JazzCash and enter the transaction reference above."}
                        </p>
                      </div>
                    )}

                    {paymentMethod === "creditcard" && (
                      <>
                        <div>
                          <Label htmlFor="cardName">Cardholder Name</Label>
                          <Input
                            id="cardName"
                            name="cardName"
                            value={cardData.cardName}
                            onChange={handleCardChange}
                            placeholder="John Doe"
                          />
                        </div>
                        <div>
                          <Label htmlFor="cardNumber">Card Number</Label>
                          <Input
                            id="cardNumber"
                            name="cardNumber"
                            value={cardData.cardNumber}
                            onChange={handleCardChange}
                            placeholder="1234 5678 9012 3456"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiry">Expiry Date</Label>
                            <Input
                              id="expiry"
                              name="expiry"
                              value={cardData.expiry}
                              onChange={handleCardChange}
                              placeholder="MM/YY"
                            />
                          </div>
                          <div>
                            <Label htmlFor="cvc">CVC</Label>
                            <Input
                              id="cvc"
                              name="cvc"
                              value={cardData.cvc}
                              onChange={handleCardChange}
                              placeholder="123"
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </Card>
            )}

            {/* Order Confirmation */}
            {step === "confirmation" && (
              <Card className="p-6 md:p-8">
                <div className="text-center mb-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.2 }}
                    className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
                  >
                    <Check className="w-8 h-8 text-green-600" />
                  </motion.div>
                  <h2 className="text-3xl font-serif font-light mb-2">
                    Thank You!
                  </h2>
                  <p className="text-foreground/70">
                    Your order has been confirmed.
                  </p>
                </div>

                {/* Order Details */}
                <div className="space-y-6 mb-8 pb-8 border-b border-border">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-foreground/60 mb-1">Order Number</p>
                      <p className="font-semibold">#VEL{Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-foreground/60 mb-1">Order Date</p>
                      <p className="font-semibold">{new Date().toLocaleDateString()}</p>
                    </div>
                  </div>

                  {/* Payment Method Details */}
                  <div>
                    <p className="text-xs text-foreground/60 mb-2">Payment Method</p>
                    <div className="p-4 bg-secondary/50 rounded-lg">
                      {paymentMethod === "easypaisa" && (
                        <div>
                          <p className="font-semibold mb-2">Easypaisa Transfer</p>
                          <p className="text-sm text-foreground/70 mb-2">
                            Send to: <span className="font-medium">03119769550</span>
                          </p>
                          <p className="text-sm text-foreground/70 mb-2">
                            Account: <span className="font-medium">Aqsa Zareen</span>
                          </p>
                          <p className="text-sm text-foreground/70">
                            Reference: <span className="font-medium">{transactionRef}</span>
                          </p>
                        </div>
                      )}
                      {paymentMethod === "jazzcash" && (
                        <div>
                          <p className="font-semibold mb-2">JazzCash Transfer</p>
                          <p className="text-sm text-foreground/70">
                            Reference: <span className="font-medium">{transactionRef}</span>
                          </p>
                        </div>
                      )}
                      {paymentMethod === "creditcard" && (
                        <div>
                          <p className="font-semibold mb-2">Credit Card Payment</p>
                          <p className="text-sm text-foreground/70">
                            Card: <span className="font-medium">****{cardData.cardNumber.slice(-4)}</span>
                          </p>
                          <p className="text-xs text-foreground/60 mt-2">Processing...</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Shipping Address */}
                  <div>
                    <p className="text-xs text-foreground/60 mb-2">Shipping To</p>
                    <div className="p-4 bg-secondary/50 rounded-lg text-left text-sm">
                      <p className="font-medium">{formData.firstName} {formData.lastName}</p>
                      <p className="text-foreground/70">{formData.address}</p>
                      <p className="text-foreground/70">{formData.city}, {formData.state} {formData.zip}</p>
                      <p className="text-foreground/70">{formData.country}</p>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-foreground/70 mb-6">
                  Confirmation sent to <span className="font-medium">{formData.email}</span>
                </p>

                <Link href="/shop" asChild>
                  <Button className="w-full">Continue Shopping</Button>
                </Link>
              </Card>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div>
            <Card className="p-6 sticky top-20">
              <h3 className="text-lg font-serif font-light mb-4">Order Summary</h3>
              <div className="space-y-3 mb-4">
                {cart.items.map((item) => (
                  <div key={item.lineId} className="flex justify-between text-sm">
                    <span>{item.productTitle} x{item.quantity}</span>
                    <span>${item.lineTotal.amount}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${cart.subtotal.amount}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>$0.00</span>
                </div>
                <div className="flex justify-between font-semibold text-lg mt-4 pt-4 border-t border-border">
                  <span>Total</span>
                  <span>${cart.total.amount}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === "cart"}
          >
            Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={step === "confirmation"}
          >
            {step === "confirmation" ? "Order Complete" : "Next"}
            {step !== "confirmation" && <ChevronRight className="w-4 h-4 ml-2" />}
          </Button>
        </div>
      </div>

      <Footer />
    </div>
  );
}
