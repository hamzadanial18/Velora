import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link, useLocation } from "wouter";
import { Heart, LogOut, User, ShoppingBag } from "lucide-react";
import { useState } from "react";

export default function Account() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"profile" | "orders" | "wishlist">(
    "profile"
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-serif font-light mb-4">
              Sign In to Your Account
            </h1>
            <p className="text-foreground/60 mb-8">
              Access your profile, order history, and wishlist.
            </p>
            <Button size="lg">Sign In</Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <div className="flex-1 container py-12 md:py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Header */}
          <div className="flex items-start justify-between mb-12">
            <div>
              <h1 className="text-4xl md:text-5xl font-serif font-light tracking-wide mb-2">
                My Account
              </h1>
              <p className="text-foreground/60">
                Welcome back, {user?.name || "Guest"}
              </p>
            </div>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar Navigation */}
            <div className="lg:col-span-1">
              <div className="space-y-2">
                {[
                  { id: "profile", label: "Profile", icon: User },
                  { id: "orders", label: "Order History", icon: ShoppingBag },
                  { id: "wishlist", label: "Wishlist", icon: Heart },
                ].map(({ id, label, icon: Icon }) => (
                  <motion.button
                    key={id}
                    onClick={() =>
                      setActiveTab(id as "profile" | "orders" | "wishlist")
                    }
                    whileHover={{ x: 4 }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      activeTab === id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-secondary"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{label}</span>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                {/* Profile Tab */}
                {activeTab === "profile" && (
                  <Card className="p-6 md:p-8">
                    <h2 className="text-2xl font-serif font-light mb-6">
                      Profile Information
                    </h2>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm text-foreground/60">
                          Full Name
                        </label>
                        <p className="text-lg font-medium">{user?.name}</p>
                      </div>
                      <div>
                        <label className="text-sm text-foreground/60">
                          Email Address
                        </label>
                        <p className="text-lg font-medium">{user?.email}</p>
                      </div>
                      <div>
                        <label className="text-sm text-foreground/60">
                          Member Since
                        </label>
                        <p className="text-lg font-medium">
                          {user?.createdAt
                            ? new Date(user.createdAt).toLocaleDateString()
                            : "N/A"}
                        </p>
                      </div>
                    </div>
                    <Button className="mt-8">Edit Profile</Button>
                  </Card>
                )}

                {/* Orders Tab */}
                {activeTab === "orders" && (
                  <Card className="p-6 md:p-8">
                    <h2 className="text-2xl font-serif font-light mb-6">
                      Order History
                    </h2>
                    <div className="text-center py-12">
                      <ShoppingBag className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
                      <p className="text-foreground/60 mb-4">
                        You haven't placed any orders yet.
                      </p>
                      <Link href="/shop/clothing">
                        <Button asChild>
                          <a>Start Shopping</a>
                        </Button>
                      </Link>
                    </div>
                  </Card>
                )}

                {/* Wishlist Tab */}
                {activeTab === "wishlist" && (
                  <Card className="p-6 md:p-8">
                    <h2 className="text-2xl font-serif font-light mb-6">
                      My Wishlist
                    </h2>
                    <div className="text-center py-12">
                      <Heart className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
                      <p className="text-foreground/60 mb-4">
                        Your wishlist is empty.
                      </p>
                      <p className="text-sm text-foreground/60 mb-6">
                        Add items to your wishlist to save them for later.
                      </p>
                      <Link href="/shop/clothing">
                        <Button asChild>
                          <a>Explore Products</a>
                        </Button>
                      </Link>
                    </div>
                  </Card>
                )}
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
}
